<h2>Log Data in form</h2>

<form action="/logstore" method="POST">
    <?php echo csrf_field(); ?>
    <label>User Id:</label><br>
    <input type="text" name="user_id"><br>
    <label>First In:</label><br>
    <input type="text" name="fin"><br>
    <label >Last out:</label><br>
    <input type="text" name="lout"><br><br>
    <input type="submit" value="Submit">
</form>   <?php /**PATH C:\Users\Shahi\Pictures\Paxzone\paxzone\resources\views/logdatain.blade.php ENDPATH**/ ?>