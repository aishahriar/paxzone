<table>
    <tr>
      <th>ID</th>
      <th>First In</th>
      <th>last Out</th>
    </tr>
    <?php
            $i=1;
        ?>
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($i++); ?></td>
      <td><?php echo e($log->fin); ?></td>
      <td><?php echo e($log->lout); ?></td>
    </tr>                            
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
<?php /**PATH C:\Users\Shahi\Pictures\Paxzone\paxzone\resources\views/logdatashow.blade.php ENDPATH**/ ?>